# SOAL 1 - Menghitung rata-rata
# Tuliskan program untuk Soal 1 di bawah ini
num = eval(input("Masukkan bilangan pertama: "))
num1 = eval(input("Masukkan bilangan kedua: "))
num2 = eval(input("Masukkan bilangan ketiga: "))
print("rata-rata bilangan", num, num1,"dan", num2, "adalah", num+num1+num2/3)




# SOAL 2 - Menulis kelipatan bilangan
# Tuliskan program untuk Soal 2 di bawah ini
bilangan = int(input("Masukan sebuah bilangan bulat: "))
print(bilangan, bilangan*2, bilangan*3, bilangan*4, bilangan*5, sep="-")
